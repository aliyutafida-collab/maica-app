import express, { type Request, Response, NextFunction } from "express";
import cors from "cors";
import { registerRoutes } from "./routes";

const app = express();

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}

// CORS Configuration for Production
const allowedOrigins = [
  'https://maica.com',
  'https://www.maica.com',
  'http://localhost:5000',  // Development
  'http://localhost:5173',  // Vite dev server
  'http://localhost:3000',  // Alternative port
  'http://0.0.0.0:5000',   // Replit
];

// Add Replit domains dynamically
if (process.env.REPL_ID) {
  allowedOrigins.push(
    `https://${process.env.REPL_SLUG}-${process.env.REPL_OWNER}.replit.dev`,
    `https://${process.env.REPL_ID}.replit.dev`,
    `https://${process.env.REPL_SLUG}-${process.env.REPL_OWNER}.replit.app`,
    `https://${process.env.REPL_ID}.replit.app`
  );
}

app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (like mobile apps, Postman, or same-origin)
    if (!origin) return callback(null, true);
    
    // Development: allow all Replit domains
    if (process.env.NODE_ENV !== 'production' && origin.includes('replit')) {
      return callback(null, true);
    }
    
    // Check against whitelist
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else if (process.env.NODE_ENV !== 'production') {
      // In development, allow localhost and similar
      if (origin.includes('localhost') || origin.includes('127.0.0.1') || origin.includes('0.0.0.0')) {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  maxAge: 86400  // 24 hours
}));

app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    // Log all API requests (routes don't have /api prefix in this file)
    let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
    if (capturedJsonResponse) {
      logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
    }

    if (logLine.length > 80) {
      logLine = logLine.slice(0, 79) + "…";
    }

    console.log(logLine);
  });

  next();
});

// Health check endpoint
app.get("/health", (_req, res) => {
  res.send("OK");
});

// Register all API routes (routes are already prefixed with /api in registerRoutes)
registerRoutes(app);

// Error handling middleware
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";

  res.status(status).json({ message });
  console.error(err);
});

export default app;

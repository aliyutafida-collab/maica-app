import app from "./app";
import path from "path";
import { fileURLToPath } from "url";

// Export app for Vercel Serverless
export default app;

// Start server in both development and production
const port = parseInt(process.env.PORT || "5000", 10);
const host = "0.0.0.0"; // Listen on all network interfaces

const server = app.listen(port, host, async () => {
  const env = process.env.NODE_ENV || "development";
  console.log(`[${env}] Server running on http://${host}:${port}`);
  
  try {
    // Use computed path to prevent esbuild from statically analyzing vite.ts
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const vitePath = path.join(__dirname, "vite.js");
    const { setupVite, serveStatic } = await import(vitePath);
    
    if (env === "development") {
      await setupVite(app, server);
    } else {
      serveStatic(app);
    }
  } catch (err) {
    console.error("Failed to load vite module:", err);
    // In production with bundled code, just serve static files
    if (env !== "development") {
      try {
        const fs = await import("fs");
        const expressModule = await import("express");
        const express = expressModule.default;
        const distPath = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "public");
        if (fs.existsSync(distPath)) {
          app.use(express.static(distPath));
          app.use("*", (_req: any, res: any) => {
            res.sendFile(path.resolve(distPath, "index.html"));
          });
          console.log("Serving static files from:", distPath);
        }
      } catch (e) {
        console.error("Static file serving failed:", e);
      }
    }
  }
});
